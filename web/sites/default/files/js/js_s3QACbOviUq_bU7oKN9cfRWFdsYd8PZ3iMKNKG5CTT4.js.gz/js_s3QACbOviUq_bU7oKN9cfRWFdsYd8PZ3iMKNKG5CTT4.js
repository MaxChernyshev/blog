/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.barrio_custom_subtheme = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
